#make_bin#
ORG 0000H

JMP START

PORTA EQU 00H 
PORTB EQU 02H 
PORTC EQU 04H 
CTRL  EQU 06H 

START:
    MOV AX, CS
    MOV DS, AX
    MOV ES, AX

    MOV AL, 80H
    OUT CTRL, AL

MAIN_LOOP:
    MOV BX, OFFSET FONT_DATA 
    MOV DI, 10               

DISPLAY_DIGIT:
    MOV BP, 40               

SCAN_LOOP:
    MOV SI, BX               
    MOV AH, 01H              
    MOV CX, 8                

COL_LOOP:
    MOV AL, [SI]
    NOT AL                   
    OUT PORTC, AL

    MOV AL, AH
    OUT PORTA, AL

    CALL MUX_DELAY

    MOV AL, 00H
    OUT PORTA, AL

    ROL AH, 1                
    INC SI                   
    LOOP COL_LOOP            

    
    DEC BP
    JNZ SCAN_LOOP

    
    ADD BX, 8                
    DEC DI                   
    JNZ DISPLAY_DIGIT

    JMP MAIN_LOOP            


MUX_DELAY PROC
    PUSH CX
    MOV CX, 25               
DELAY_LOOP:
    NOP
    LOOP DELAY_LOOP
    POP CX
    RET
MUX_DELAY ENDP


FONT_DATA:
    ; '0'
    DB 00H, 3EH, 51H, 49H, 45H, 3EH, 00H, 00H
    ; '1'
    DB 00H, 00H, 42H, 7FH, 40H, 00H, 00H, 00H
    ; '2'
    DB 00H, 42H, 61H, 51H, 49H, 46H, 00H, 00H
    ; '3'
    DB 00H, 21H, 41H, 49H, 4DH, 33H, 00H, 00H
    ; '4'
    DB 00H, 18H, 14H, 12H, 7FH, 10H, 00H, 00H
    ; '5'
    DB 00H, 27H, 45H, 45H, 45H, 39H, 00H, 00H
    ; '6'
    DB 00H, 3CH, 4AH, 49H, 49H, 30H, 00H, 00H
    ; '7'
    DB 00H, 01H, 71H, 09H, 05H, 03H, 00H, 00H
    ; '8'
    DB 00H, 36H, 49H, 49H, 49H, 36H, 00H, 00H
    ; '9'
    DB 00H, 06H, 49H, 49H, 29H, 1EH, 00H, 00H